#!/bin/sh

#-------------------------------------------------
#  Common variables
#-------------------------------------------------

FULL_PRODUCT_NAME="Check Point Mobile Access Portal Agent"
SHORT_PRODUCT_NAME="Mobile Access Portal Agent"
INSTALL_DIR=/usr/bin/cshell
INSTALL_CERT_DIR=${INSTALL_DIR}/cert
BAD_CERT_FILE=${INSTALL_CERT_DIR}/.BadCertificate

PATH_TO_JAR=${INSTALL_DIR}/CShell.jar

AUTOSTART_DIR=
USER_NAME=

CERT_DIR=/etc/ssl/certs
CERT_NAME=CShell_Certificate

LOGS_DIR=/var/log/cshell


#-------------------------------------------------
#  Common functions
#-------------------------------------------------

debugger(){
	read -p "DEBUGGER> Press [ENTER] key to continue..." key
}

show_error(){
    echo
    echo "$1. Installation aborted."
}

IsCShellStarted(){
   PID=`ps ax | grep -v grep | grep -F -i "${PATH_TO_JAR}" | awk '{print $1}'`

   if [ -z "$PID" ]
      then
          echo 0
      else
          echo 1
   fi
}

KillCShell(){
   for CShellPIDs in `ps ax | grep -v grep | grep -F -i "${PATH_TO_JAR}" | awk ' { print $1;}'`; do
       kill -15 ${CShellPIDs};
   done
}

IsFFStarted(){
   PID=`ps ax | grep -v grep | grep -i "firefox" | awk '{print $1}'`

   if [ -z "$PID" ]
      then
          echo 0
      else
          echo 1
   fi
}

IsChromeStarted(){
   PID=`ps ax | grep -v grep | grep -i "google/chrome" | awk '{print $1}'`

   if [ -z "$PID" ]
      then
          echo 0
      else
          echo 1
   fi
}

IsChromeInstalled()
{
  google-chrome --version > /dev/null 2>&1
  res=$?

  if [ ${res} = 0 ]
    then 
    echo 1
  else 
    echo 0
  fi
}

IsFirefoxInstalled()
{
  firefox --version > /dev/null 2>&1
  res=$?

  if [ "${res}" != "127" ]
    then 
    echo 1
  else 
    echo 0
  fi
}

IsNotSupperUser()
{
	if [ `id -u` != 0 ]
	then
		return 0
	fi

	return 1
}

GetUserName() 
{
    user_name=`who | head -n 1 | awk '{print $1}'`
    echo ${user_name}
}

GetUserHomeDir() 
{
    user_name=$(GetUserName)
    echo $( getent passwd "${user_name}" | cut -d: -f6 )
}

GetFirstUserGroup() 
{
    group=`groups $(GetUserName) | awk {'print $3'}`
    if [ -z "$group" ]
    then 
	group="root"
    fi

    echo $group
}


GetFFProfilePaths()
{
    USER_HOME=$(GetUserHomeDir)

    if [ ! -f ${USER_HOME}/.mozilla/firefox/installs.ini ]
       then
		   return 1
    fi


	ff_profile_paths=""
	while IFS= read -r line; do
		match=$(echo "$line" | grep -c -o "Default")

		if [ "$match" != "0" ]
       then
			line=$( echo "$line" | sed 's/ /<+>/ g')
			line=$( echo "$line" | sed 's/Default=//')

			if [ $(echo "$line" | cut -c 1-1) = '/' ]
       then
				ff_profile_paths=$(echo "$ff_profile_paths<|>$line")
			else
				ff_profile_paths=$(echo "$ff_profile_paths<|>${USER_HOME}/.mozilla/firefox/$line")
			fi		
    fi
	done < "${USER_HOME}/.mozilla/firefox/installs.ini"

	ff_profile_paths=$( echo $ff_profile_paths | sed 's/^<|>//')


    echo "${ff_profile_paths}"
    return 0
}

GetFFDatabases()
{
    #define FF profile dir
    FF_PROFILE_PATH=$(GetFFProfilePaths)
	res=$?

    if [ "$res" -eq "1" ] || [ -z "$FF_PROFILE_PATH" ]
       then
       return 1
    fi

	ff_profiles=$(echo "$FF_PROFILE_PATH" | sed 's/<|>/ /' )

	ff_databases=""

	for ff_profile in $ff_profiles
	do
		ff_profile=$(echo "$ff_profile" | sed 's/<+>/ / g')

		if [ -f "${ff_profile}/cert9.db" ]
         then
			ff_databases=$(echo "$ff_databases<|>sql:${ff_profile}")
		else
			ff_databases=$(echo "$ff_databases<|>${ff_profile}")
		fi
	done

	ff_databases=$(echo "$ff_databases" | sed 's/ /<+>/ g')	
	ff_databases=$(echo "$ff_databases" | sed 's/^<|>//' )

    echo "${ff_databases}"
    return 0
}

GetChromeProfilePath()
{
  chrome_profile_path="$(GetUserHomeDir)/.pki/nssdb"

  if [ ! -d "${chrome_profile_path}" ]
    then
    show_error "Cannot find Chrome profile"
    return 1
  fi

  echo "${chrome_profile_path}"
  return 0
}

DeleteCertificate()
{
    #define FF database
    FF_DATABASES=$(GetFFDatabases)

if [ $? -ne 0 ]
then
            return 1

fi


	
	FF_DATABASES=$(echo "$FF_DATABASES" | sed 's/<|>/ /') 

	for ff_db in $FF_DATABASES
	do
		ff_db=$(echo "$ff_db" | sed 's/<+>/ / g')
	
	#remove cert from Firefox
		for CSHELL_CERTS in `certutil -L -d "${ff_db}" | grep -F -i "${CERT_NAME}" | awk '{print $1}'`
        do
		    `certutil -D -n "${CERT_NAME}" -d "${ff_db}"`
        done


	    CSHELL_CERTS=`certutil -L -d "${ff_db}" | grep -F -i "${CERT_NAME}" | awk '{print $1}'`
    if [ ! -z "$CSHELL_CERTS" ]
       then
           echo "Cannot remove certificate from Firefox profile"
    fi
	done

    
    if [ "$(IsChromeInstalled)" = 1 ]
      then
        #define Chrome profile dir
        CHROME_PROFILE_PATH=$(GetChromeProfilePath)

        if [ -z "$CHROME_PROFILE_PATH" ]
          then
              show_error "Cannot get Chrome profile"
              return 1
        fi

        #remove cert from Chrome
        for CSHELL_CERTS in `certutil -L -d "sql:${CHROME_PROFILE_PATH}" | grep -F -i "${CERT_NAME}" | awk '{print $1}'`
        do
          `certutil -D -n "${CERT_NAME}" -d "sql:${CHROME_PROFILE_PATH}"`
        done


        CSHELL_CERTS=`certutil -L -d "sql:${CHROME_PROFILE_PATH}" | grep -F -i "${CERT_NAME}" | awk '{print $1}'`

        if [ ! -z "$CSHELL_CERTS" ]
          then
          echo "Cannot remove certificate from Chrome profile"
        fi
    fi

	rm -rf ${INSTALL_CERT_DIR}/${CERT_NAME}.*
	
	rm -rf /etc/ssl/certs/${CERT_NAME}.p12
}


#-------------------------------------------------
#  Cleanup functions
#-------------------------------------------------


cleanupTmp() {
	rm -rf ${INSTALL_DIR}/tmp
}


cleanupInstallDir() {
	rm -rf ${INSTALL_DIR}
	
	#Remove  autostart file
	if [ -f "$(GetUserHomeDir)/.config/autostart/cshell.desktop" ]
	then
		rm -f "$(GetUserHomeDir)/.config/autostart/cshell.desktop"
	fi
}


cleanupCertificates() {
	DeleteCertificate
}


cleanupAll(){
	cleanupCertificates
	cleanupTmp
	cleanupInstallDir
}


cleanupOnTrap() {
	echo "Installation has been interrupted"
	
	if [ ${CLEAN_ALL_ON_TRAP} = 0 ]
		then
			cleanupTmp
		else
			cleanupAll
			echo "Your previous version of ${FULL_PRODUCT_NAME} has already been removed"
			echo "Please restart installation script"
	fi
}
#-------------------------------------------------
#  CShell Uninstaller
#  
#  Script logic:
#	 1. Check for SU 
#	 2. Stop CShell
#	 3. Delete CShell files and certificates
#  
#-------------------------------------------------

trap cleanupOnTrap 2
trap cleanupOnTrap 3
trap cleanupOnTrap 13
trap cleanupOnTrap 15

CLEAN_ALL_ON_TRAP=0

# Check if supper user permissions are required
if IsNotSupperUser
then
    # show explanation if sudo password has not been entered for this terminal session
    sudo -n true > /dev/null 2>&1
    res=$?

    if [ ${res} != 0 ]
        then
        echo "The installation script requires root permissions"
        echo "Please provide the root password"
    fi  

    #rerun script wuth SU permissions
    string=`cat /etc/os-release | grep -i "^name=" | grep -Fi "ubuntu"`

    if [ -z $string ]
    then 
        su -c "sh $0 $*"
    else 
        sudo sh "$0" "$*"
    fi

    exit 1
fi  

echo -n "Uninstalling ${FULL_PRODUCT_NAME}... "

# stop CShell
if [ $(IsCShellStarted) = 1 ]
    then
        echo
        echo "Shutdown ${SHORT_PRODUCT_NAME}"
        KillCShell
        STATUS=$?
        if [ ${STATUS} != 0 ]
            then
                show_error "Cannot shutdown ${SHORT_PRODUCT_NAME}"
                exit 1
        fi

        #wait up to 10 sec for CShell to close 
        for i in $(seq 1 10)
            do
                if [ $(IsCShellStarted) = 0 ]
                    then
                        break
                    else
                        if [ $i = 10 ]
                            then
                                show_error "Cannot shutdown ${SHORT_PRODUCT_NAME}"
                                exit 1
                            else
                                sleep 1
                        fi
                fi
        done
fi

# require Firefox to be closed during certificate installation
while [  $(IsFFStarted) = 1 ]
    do
        echo
        echo "Firefox must be closed to proceed with ${SHORT_PRODUCT_NAME} installation."
        read -p "Press [ENTER] key to continue..." key
        sleep 2
    done

# remove files and certificates
cleanupAll

# remove logs
rm -rf "${LOGS_DIR}"

echo "Done"
echo "Uninstallation complete"
exit 0
